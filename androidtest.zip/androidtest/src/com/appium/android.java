package com.appium;



import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

class LaunchAppOnEmulator {

    public static void main(String[] args) throws MalformedURLException{

        DesiredCapabilities capabilities=new DesiredCapabilities();

        capabilities.setCapability("automationName", "Appium");

        capabilities.setCapability("platformName", "Android");

        capabilities.setCapability("platformVersion","8.0.0");

        capabilities.setCapability("deviceName","Pixel 2 API 26");

        capabilities.setCapability("app","//Users//lubnashaikh//Downloads//LiSTNR_v3.17.2.171_apkpure.com.apk");

//        capabilities.setCapability("appPackage","io.selendroid.testapp");

//        capabilities.setCapability("appActivity","io.selendroid.testapp.HomeScreenActivity");

        AndroidDriver driver=new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);

    }

}
